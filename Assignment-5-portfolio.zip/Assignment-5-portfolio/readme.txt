Bootstrap components used-

1. navbar
2. Carausel
3. Cards
4. Progress bar
5. Accordian
6. Table
7. Form
8. Button
9. Image
10. off canvas
11. Alert