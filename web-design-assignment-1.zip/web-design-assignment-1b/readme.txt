Tags used in assignment part B

1.Header- The <header> HTML element represents introductory content, typically a group of introductory or navigational aids.
2. Nav- The <nav> tag defines a set of navigation links.
3. video- The <video> tag is used to embed video content in a document, such as a movie clip or other video streams. 
4. aside- The <aside> HTML element represents a portion of a document whose content is only indirectly related to the document's main content. 
5. Footer- The <footer> tag defines a footer for a document or section.
6. Section- The <section> tag defines a section in a document.
7. audio- The HTML <audio> element is used to play an audio file on a web page. 


NUID- 002926665