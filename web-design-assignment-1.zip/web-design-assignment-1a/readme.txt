Tags used in assignment part A

1. Favicon- A favicon is a small image displayed next to the page title in the browser tab.
2. Images- The HTML <img> tag is used to embed an image in a web page.
3. Table- HTML <table> allow web developers to arrange data into rows and columns. 
4. Button- The <button> tag defines a clickable button.
5. Hyperlink- The <a> tag defines a hyperlink, which is used to link from one page to another.
6. Form- The <form> element is a container for different types of input elements, such as: text fields, checkboxes, radio buttons, submit buttons, etc.


NUID- 002926665